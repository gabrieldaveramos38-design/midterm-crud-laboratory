# placeholder settings; user must replace with actual Django project settings
